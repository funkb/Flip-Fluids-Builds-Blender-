Data for running example scenes in this directory and subdirectories are licensed 
under the Standard Royalty Free License:

--------------------------------------------------------------------------------
Standard Royalty Free License

The Standard Royalty Free license grants you, the purchaser, the ability to make 
use of the purchased product for personal, educational, or commercial purposes 
as long as those purposes do not violate any of the following:

    - You may not resell, redistribute, or repackage the purchased product 
      without explicit permission from the original author.

    - You may not use the purchased product in a logo, watermark, or trademark 
      of any kind Exception: shader, material, and texture products are exempt 
      from this rule. These products are much the same as colors, and such are a 
      secondary meaning and may be used as part of a logo, watermark, or 
      trademark.
--------------------------------------------------------------------------------